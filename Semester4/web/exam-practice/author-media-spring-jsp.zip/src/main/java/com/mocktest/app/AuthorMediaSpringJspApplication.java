package com.mocktest.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorMediaSpringJspApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthorMediaSpringJspApplication.class, args);
	}

}
